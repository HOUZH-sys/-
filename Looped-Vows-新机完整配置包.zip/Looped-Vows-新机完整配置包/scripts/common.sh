#!/usr/bin/env bash
set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSIONS_FILE="$PACKAGE_ROOT/config/versions.json"
REPOSITORY_BUNDLE="$PACKAGE_ROOT/payload/looped-vows-repository.bundle"
MCP_CONFIG="$PACKAGE_ROOT/config/runtime-mcp.toml"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
DEFAULT_PROJECT_ROOT="$HOME/Documents/ChatGPT/游戏开发"
PROJECT_ROOT="${LOOPED_VOWS_HOME:-$DEFAULT_PROJECT_ROOT}"

log() {
  printf '%s\n' "$*"
}

warn() {
  printf 'WARN %s\n' "$*" >&2
}

fail() {
  printf 'FAIL %s\n' "$*" >&2
  exit 1
}

need() {
  command -v "$1" >/dev/null 2>&1 || fail "缺少命令: $1"
}

require_macos() {
  [ "$(uname -s)" = "Darwin" ] || fail "本交付包只支持 macOS"
}

version_value() {
  jq -er "$1" "$VERSIONS_FILE"
}

repository_commit() {
  git -C "$1" rev-parse --verify 'HEAD^{commit}'
}

bundle_commit() {
  git bundle list-heads "$REPOSITORY_BUNDLE" |
    awk '$2 == "refs/heads/main" {print $1; exit}'
}

sha_file() {
  algorithm="$1"
  path="$2"
  shasum -a "$algorithm" "$path" | awk '{print $1}'
}

verify_sha() {
  algorithm="$1"
  expected="$2"
  path="$3"
  [ -f "$path" ] || fail "缺少文件: $path"
  actual="$(sha_file "$algorithm" "$path")"
  [ "$actual" = "$expected" ] || fail "校验值不匹配: $path"
}

headroom_python() {
  candidate="$HOME/.local/share/uv/tools/headroom-ai/bin/python"
  [ -x "$candidate" ] && printf '%s\n' "$candidate"
}

project_python() {
  if [ -x "$PROJECT_ROOT/.tools/bin/python3" ]; then
    printf '%s\n' "$PROJECT_ROOT/.tools/bin/python3"
    return
  fi

  if [ -d "$PROJECT_ROOT/.tools/uv/python" ]; then
    candidate="$(
      find "$PROJECT_ROOT/.tools/uv/python" -type f \
        -path '*/bin/python3' -perm -111 -print 2>/dev/null |
        sort |
        tail -n 1
    )"
    if [ -n "$candidate" ]; then
      printf '%s\n' "$candidate"
      return
    fi
  fi
}

python_command() {
  for candidate in "$(headroom_python || true)" "$(project_python || true)" \
    /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3
  do
    [ -n "$candidate" ] || continue
    [ -x "$candidate" ] || continue
    if "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' \
      >/dev/null 2>&1; then
      printf '%s\n' "$candidate"
      return
    fi
  done
  fail "需要 Python 3.11 或更新版本；请先运行 10-bootstrap.command"
}

activate_project_path() {
  export PATH="$PROJECT_ROOT/.tools/bin:$PROJECT_ROOT/.tools/node/v24.22.0/bin:$PATH"
  export UV_TOOL_DIR="$PROJECT_ROOT/.tools/uv/tool"
  export UV_TOOL_BIN_DIR="$PROJECT_ROOT/.tools/bin"
  export UV_PYTHON_INSTALL_DIR="$PROJECT_ROOT/.tools/uv/python"
  export UV_CACHE_DIR="$PROJECT_ROOT/.tools/uv/cache"
}

download_verified() {
  url="$1"
  expected="$2"
  algorithm="$3"
  destination="$4"
  mkdir -p "$(dirname "$destination")"
  if [ -f "$destination" ]; then
    if verify_sha "$algorithm" "$expected" "$destination" >/dev/null 2>&1; then
      log "CACHED $(basename "$destination")"
      return
    fi
    fail "已有缓存校验失败，请检查后移走: $destination"
  fi
  partial="$destination.partial"
  rm -f "$partial"
  log "DOWNLOAD $(basename "$destination")"
  curl -fL --retry 3 --retry-delay 2 --continue-at - \
    "$url" -o "$partial"
  verify_sha "$algorithm" "$expected" "$partial"
  mv "$partial" "$destination"
  log "VERIFIED $(basename "$destination")"
}

ensure_clean_git_clone() {
  path="$1"
  if [ -e "$path" ]; then
    [ -d "$path/.git" ] || fail "目标存在但不是 Git 克隆: $path"
    log "REUSE $(repository_commit "$path") $path"
    return
  fi
  fail "未找到项目克隆: $path"
}

pause_if_interactive() {
  if [ -t 0 ]; then
    printf '\n按回车关闭窗口。'
    read -r _
  fi
}

run_launcher() {
  script="$1"
  shift
  "$script" "$@"
  pause_if_interactive
}
