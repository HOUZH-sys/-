#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

require_macos
for name in git curl jq shasum tar unzip ditto codesign; do
  need "$name"
done
ensure_clean_git_clone "$PROJECT_ROOT"

case "$(uname -m)" in
  x86_64) node_arch=x64 ;;
  arm64) node_arch=arm64 ;;
  *) fail "不支持的 CPU 架构: $(uname -m)" ;;
esac

cache="$PROJECT_ROOT/.tools/cache/downloads"
node_version="$(version_value '.node.version')"
node_url="$(version_value ".node.${node_arch}.url")"
node_sha="$(version_value ".node.${node_arch}.sha256")"
node_archive="$cache/node-v$node_version-darwin-$node_arch.tar.gz"
node_target="$PROJECT_ROOT/.tools/node/v$node_version"
mkdir -p "$cache" "$PROJECT_ROOT/.tools/node" "$PROJECT_ROOT/.tools/bin"

download_verified "$node_url" "$node_sha" 256 "$node_archive"
if [ -x "$node_target/bin/node" ]; then
  [ "$("$node_target/bin/node" --version)" = "v$node_version" ] ||
    fail "已有 Node.js 版本不匹配: $node_target"
else
  [ ! -e "$node_target" ] || fail "Node.js 目标目录存在但不完整: $node_target"
  temp_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-node.XXXXXX")"
  trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
  tar -xzf "$node_archive" -C "$temp_dir"
  ditto "$temp_dir/node-v$node_version-darwin-$node_arch" "$node_target"
  rm -rf "$temp_dir"
  trap - EXIT HUP INT TERM
fi

for binary in node npm npx; do
  link="$PROJECT_ROOT/.tools/bin/$binary"
  expected="../node/v$node_version/bin/$binary"
  if [ -L "$link" ]; then
    current="$(readlink "$link")"
    [ "$current" = "$expected" ] || fail "已有 $binary 链接指向其他版本: $current"
  elif [ -e "$link" ]; then
    fail "$binary 已作为普通文件存在，拒绝覆盖: $link"
  else
    ln -s "$expected" "$link"
  fi
done

activate_project_path
"$node_target/bin/node" --version
"$node_target/bin/npm" --version

godot_version="$(version_value '.godot.version')"
godot_app="$PROJECT_ROOT/.tools/godot/$godot_version-stable/Godot.app"
godot_bin="$godot_app/Contents/MacOS/Godot"
godot_zip_url="$(version_value '.godot.macos_zip.url')"
godot_zip_sha="$(version_value '.godot.macos_zip.sha512')"
godot_zip="$cache/Godot_v$godot_version-stable_macos.universal.zip"

download_verified "$godot_zip_url" "$godot_zip_sha" 512 "$godot_zip"
if [ -x "$godot_bin" ]; then
  [ "$("$godot_bin" --version)" = "$(version_value '.godot.version_full')" ] ||
    fail "已有 Godot 版本不匹配: $godot_bin"
else
  [ ! -e "$godot_app" ] || fail "Godot 目标存在但不完整: $godot_app"
  temp_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-godot.XXXXXX")"
  trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
  unzip -q "$godot_zip" -d "$temp_dir/app"
  extracted_app="$(find "$temp_dir/app" -maxdepth 2 -type d -name Godot.app -print | head -n 1)"
  [ -n "$extracted_app" ] || fail "Godot 下载包中没有 Godot.app"
  mkdir -p "$(dirname "$godot_app")"
  ditto "$extracted_app" "$godot_app"
  xattr -dr com.apple.quarantine "$godot_app" 2>/dev/null || true
  rm -rf "$temp_dir"
  trap - EXIT HUP INT TERM
fi

actual_godot_sha="$(sha_file 256 "$godot_bin")"
[ "$actual_godot_sha" = "$(version_value '.godot.binary_sha256')" ] ||
  fail "Godot 可执行文件校验失败"

template_parent="$HOME/Library/Application Support/Godot/export_templates"
template_target="$template_parent/$godot_version.stable"
template_zip="$cache/Godot_v$godot_version-stable_export_templates.tpz"
download_verified \
  "$(version_value '.godot.export_templates.url')" \
  "$(version_value '.godot.export_templates.sha512')" 512 "$template_zip"

if [ -f "$template_target/macos.zip" ]; then
  verify_sha 512 \
    "$(version_value '.godot.export_templates.macos_zip_sha512')" \
    "$template_target/macos.zip"
else
  [ ! -e "$template_target" ] ||
    fail "Godot 导出模板目录存在但不完整: $template_target"
  temp_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-templates.XXXXXX")"
  trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
  unzip -q "$template_zip" -d "$temp_dir"
  extracted_templates="$(
    find "$temp_dir" -type d -path "*/templates/$godot_version.stable" -print |
      head -n 1
  )"
  [ -n "$extracted_templates" ] || fail "Godot 导出包中没有 $godot_version.stable"
  verify_sha 512 \
    "$(version_value '.godot.export_templates.macos_zip_sha512')" \
    "$extracted_templates/macos.zip"
  mkdir -p "$template_parent"
  ditto "$extracted_templates" "$template_target"
  rm -rf "$temp_dir"
  trap - EXIT HUP INT TERM
fi

DEVTOOLS_TOOLS_DIR="$PROJECT_ROOT/.tools" \
  "$PROJECT_ROOT/automation/devtools/install.sh"

"$PROJECT_ROOT/automation/devtools/verify.sh"

for role in developer tester; do
  workspace="$PROJECT_ROOT/.game-auto/agent-round/$role"
  [ -d "$workspace/.git" ] || fail "$role 独立克隆不存在，请先运行 10-bootstrap.command"
  if [ ! -e "$workspace/.tools" ]; then
    ln -s ../../../.tools "$workspace/.tools"
  fi
done

log "PASS project-toolchain"
log "NEXT 登录 Codex，配置 DeepSeek 凭据，然后运行 30-configure-codex.command"
