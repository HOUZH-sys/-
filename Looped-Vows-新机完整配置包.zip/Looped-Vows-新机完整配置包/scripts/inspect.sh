#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

require_macos
activate_project_path
failures=0
warnings=0

record() {
  status="$1"
  label="$2"
  printf '%-4s %s\n' "$status" "$label"
  case "$status" in
    FAIL) failures=$((failures + 1)) ;;
    WARN) warnings=$((warnings + 1)) ;;
  esac
}

check_command() {
  name="$1"
  if command -v "$name" >/dev/null 2>&1; then
    record PASS "命令 $name"
  else
    record FAIL "命令 $name"
  fi
}

log "Looped Vows 新 Mac 只读体检"
log "macOS $(sw_vers -productVersion) ($(sw_vers -buildVersion)), $(uname -m)"
log "交付包 $PACKAGE_ROOT"
log "项目路径 $PROJECT_ROOT"
log ""

for name in git curl jq shasum tar unzip ditto codesign; do
  check_command "$name"
done

if [ -x /usr/libexec/PlistBuddy ]; then
  record PASS "系统组件 PlistBuddy"
else
  record FAIL "系统组件 PlistBuddy"
fi

if xcode_path="$(xcode-select -p 2>/dev/null)"; then
  record PASS "Xcode Command Line Tools: $xcode_path"
else
  record FAIL "未安装 Xcode Command Line Tools"
fi

if [ -d /Applications/ChatGPT.app ]; then
  app_version="$(
    /usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' \
      /Applications/ChatGPT.app/Contents/Info.plist 2>/dev/null || true
  )"
  record PASS "ChatGPT Desktop ${app_version:-版本未知}"
else
  record FAIL "ChatGPT Desktop 未安装"
fi

computer_use_app="$CODEX_HOME/computer-use/Codex Computer Use.app"
if [ -d "$computer_use_app" ]; then
  cu_version="$(
    /usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' \
      "$computer_use_app/Contents/Info.plist" 2>/dev/null || true
  )"
  record PASS "Codex Computer Use ${cu_version:-版本未知}"
else
  record WARN "Codex Computer Use 尚未由 Desktop 插件安装"
fi

if [ -f "$CODEX_HOME/config.toml" ]; then
  record PASS "Codex 配置存在"
else
  record WARN "Codex 配置尚未生成；先登录 Desktop 再运行 10-bootstrap.command"
fi

for plugin in \
  'game-studio@openai-api-curated' \
  'product-design@openai-api-curated' \
  'superpowers@superpowers-dev' \
  'computer-use@openai-bundled' \
  'unified-computer-use@openai-bundled'
do
  if [ -f "$CODEX_HOME/config.toml" ] &&
    awk -v target="[plugins.\"$plugin\"]" '
      $0 == target { active = 1; next }
      /^\[/ { active = 0 }
      active && /^[[:space:]]*enabled[[:space:]]*=[[:space:]]*true[[:space:]]*$/ { found = 1 }
      END { exit(found ? 0 : 1) }
    ' "$CODEX_HOME/config.toml"; then
    record PASS "插件已启用 $plugin"
  else
    record WARN "插件尚未启用 $plugin"
  fi
done

if [ -f "$CODEX_HOME/skills/.awesome-gamedev-looped-vows.json" ]; then
  marker_commit="$(
    jq -r '.commit // "unknown"' \
      "$CODEX_HOME/skills/.awesome-gamedev-looped-vows.json"
  )"
  record PASS "awesome-gamedev 技能 $marker_commit"
else
  record WARN "awesome-gamedev 技能尚未安装"
fi

if [ -d "$PROJECT_ROOT/.git" ]; then
  record PASS "项目克隆 $(repository_commit "$PROJECT_ROOT")"
else
  record WARN "项目尚未初始化"
fi

godot="$PROJECT_ROOT/.tools/godot/4.7.2-stable/Godot.app/Contents/MacOS/Godot"
if [ -x "$godot" ]; then
  godot_version="$("$godot" --version 2>/dev/null || true)"
  if [ "$godot_version" = "4.7.2.stable.official.ed1daf0bf" ]; then
    record PASS "Godot $godot_version"
  else
    record FAIL "Godot 版本不匹配 ${godot_version:-unreadable}"
  fi
else
  record WARN "项目内 Godot 尚未安装"
fi

template_root="$HOME/Library/Application Support/Godot/export_templates/4.7.2.stable"
if [ -f "$template_root/macos.zip" ]; then
  record PASS "Godot macOS 导出模板"
else
  record WARN "Godot macOS 导出模板尚未安装"
fi

node_bin="$PROJECT_ROOT/.tools/node/v24.22.0/bin/node"
if [ -x "$node_bin" ]; then
  record PASS "Node.js $("$node_bin" --version)"
else
  record WARN "项目内 Node.js 尚未安装"
fi

if [ -x "$PROJECT_ROOT/.tools/bin/ast-grep" ]; then
  record PASS "ast-grep $("$PROJECT_ROOT/.tools/bin/ast-grep" --version | awk '{print $2}')"
else
  record WARN "ast-grep 尚未安装"
fi

if [ -x "$PROJECT_ROOT/.tools/bin/aider" ]; then
  record PASS "Aider $("$PROJECT_ROOT/.tools/bin/aider" --version | awk '{print $2}')"
else
  record WARN "Aider 尚未安装"
fi

headroom="$HOME/.local/bin/headroom"
if [ -x "$headroom" ]; then
  record PASS "Headroom $("$headroom" --version 2>/dev/null | tail -n 1)"
else
  record WARN "Headroom 尚未安装"
fi

for role in developer tester; do
  workspace="$PROJECT_ROOT/.game-auto/agent-round/$role"
  if [ -d "$workspace/.git" ]; then
    [ -L "$workspace/.tools" ] && tools_state="tools-linked" || tools_state="tools-missing"
    record PASS "$role 独立克隆 $tools_state"
  else
    record WARN "$role 独立克隆尚未建立"
  fi
done

if [ -f "$PROJECT_ROOT/automation/native-agents/routing.json" ]; then
  if jq -e \
    '.dispatch_contract.model == "deepseek-flash" and
     .dispatch_contract.thinking == "max" and
     .native_threads_only == true' \
    "$PROJECT_ROOT/automation/native-agents/routing.json" >/dev/null; then
    record PASS "原生双 Agent 路由契约"
  else
    record FAIL "原生 Agent 路由契约无效"
  fi
else
  record WARN "项目未初始化，路由契约待检查"
fi

legacy_found=0
for path in \
  "$HOME/Library/LaunchAgents/com.loopedvows.console-session-broker.plist" \
  "$HOME/Library/LaunchDaemons/com.loopedvows.console-session-broker.plist" \
  "$HOME/.codex/computer-use/CuaDriver.app" \
  "/Users/Shared/godot-playtest"
do
  if [ -e "$path" ]; then
    record FAIL "发现废弃 GUI 组件 $path"
    legacy_found=1
  fi
done
if [ "$legacy_found" -eq 0 ]; then
  record PASS "未发现 CuaDriver、共享队列或 console broker"
fi

log ""
if [ "$failures" -eq 0 ]; then
  log "PASS 只读体检没有硬失败；$warnings 个 WARN 由后续安装或人工授权补齐。"
else
  log "FAIL 只读体检发现 $failures 个硬失败，$warnings 个 WARN。"
  exit 1
fi
