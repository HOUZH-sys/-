#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

THREAD_PATTERN = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)
TEXT_FILES = (
    "AGENTS.md",
    "automation/native-agents/routing.json",
    "automation/nightshift/CONTINUOUS-OPERATIONS-PLAYBOOK.md",
    "automation/nightshift/chatgpt-rescue-heartbeat-prompt.md",
)
CLONE_ROLES = ("developer", "tester")


def fail(message: str) -> None:
    print(f"FAIL bind-native-threads: {message}", file=sys.stderr)
    raise SystemExit(1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    parser.add_argument("--developer", required=True)
    parser.add_argument("--tester", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--check", action="store_true")
    return parser.parse_args()


def validate_thread_id(value: str, label: str) -> str:
    value = value.strip().lower()
    if not THREAD_PATTERN.fullmatch(value):
        fail(f"{label} thread ID 不是合法 UUID")
    return value


def current_ids(project: Path) -> tuple[str, str]:
    routing = project / "automation/native-agents/routing.json"
    data = json.loads(routing.read_text(encoding="utf-8"))
    return (
        data["agents"]["developer"]["thread_id"],
        data["agents"]["tester"]["thread_id"],
    )


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        fail(f"git {' '.join(args)} 失败于 {repo}: {detail}")
    return result.stdout.strip()


def require_clean_repo(repo: Path, label: str) -> None:
    if not (repo / ".git").is_dir():
        fail(f"{label} 不是 Git 克隆: {repo}")
    status = git(repo, "status", "--porcelain", "--untracked-files=normal")
    if status:
        fail(f"{label} 工作区不干净；请先提交或清理后再绑定:\n{status}")


def write_atomic(path: Path, text: str) -> None:
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with open(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
        path.chmod(path.stat().st_mode & 0o777)
        Path(temp_name).replace(path)
    finally:
        temp_path = Path(temp_name)
        if temp_path.exists():
            temp_path.unlink()


def restore_files(paths: dict[Path, str]) -> None:
    for path, text in paths.items():
        path.write_text(text, encoding="utf-8")


def commit_changes(project: Path, relatives: tuple[str, ...]) -> str:
    git(project, "add", "--", *relatives)
    git(
        project,
        "-c",
        "user.name=Looped Vows Setup",
        "-c",
        "user.email=looped-vows-setup@localhost",
        "commit",
        "-m",
        "chore: bind native agent threads",
    )
    commit = git(project, "rev-parse", "--verify", "HEAD^{commit}")
    if git(project, "status", "--porcelain", "--untracked-files=normal"):
        fail("线程绑定提交后主克隆仍有未提交改动")
    return commit


def sync_clones(project: Path, commit: str) -> dict[str, str]:
    synced: dict[str, str] = {}
    for role in CLONE_ROLES:
        workspace = project / ".game-auto/agent-round" / role
        require_clean_repo(workspace, f"{role} 独立克隆")
        git(workspace, "fetch", "origin", "main")
        git(workspace, "merge", "--ff-only", "FETCH_HEAD")
        clone_head = git(workspace, "rev-parse", "--verify", "HEAD^{commit}")
        if clone_head != commit:
            fail(f"{role} 独立克隆未同步到绑定提交 {commit}")
        synced[role] = clone_head
    return synced


def main() -> None:
    args = parse_args()
    project = Path(args.project).expanduser().resolve()
    developer = validate_thread_id(args.developer, "developer")
    tester = validate_thread_id(args.tester, "tester")
    if developer == tester:
        fail("developer 与 tester 不能使用同一个 thread ID")

    routing_path = project / "automation/native-agents/routing.json"
    if not routing_path.is_file():
        fail(f"找不到路由文件: {routing_path}")

    old_developer, old_tester = current_ids(project)
    if args.check:
        if (old_developer, old_tester) != (developer, tester):
            fail("routing.json 与指定 thread ID 不一致")
        for role in CLONE_ROLES:
            workspace = project / ".game-auto/agent-round" / role
            require_clean_repo(workspace, f"{role} 独立克隆")
        print(f"PASS native-thread-binding developer={developer} tester={tester}")
        return

    require_clean_repo(project, "主克隆")
    for role in CLONE_ROLES:
        workspace = project / ".game-auto/agent-round" / role
        require_clean_repo(workspace, f"{role} 独立克隆")

    if (old_developer, old_tester) == (developer, tester):
        print(f"UNCHANGED native-thread-binding developer={developer} tester={tester}")
        return

    original: dict[Path, str] = {}
    for relative in TEXT_FILES:
        path = project / relative
        if not path.is_file():
            fail(f"缺少需要同步的文件: {relative}")
        text = path.read_text(encoding="utf-8")
        original[path] = text

    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_root = project / ".game-auto/native-thread-bind-backups" / stamp
    for path, text in original.items():
        backup = backup_root / path.relative_to(project)
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_text(text, encoding="utf-8")
        shutil.copystat(path, backup)

    commit: str | None = None
    try:
        for path, text in original.items():
            updated = text.replace(old_developer, developer).replace(old_tester, tester)
            write_atomic(path, updated)

        routing = json.loads(routing_path.read_text(encoding="utf-8"))
        if (
            routing.get("agents", {}).get("developer", {}).get("thread_id") != developer
            or routing.get("agents", {}).get("tester", {}).get("thread_id") != tester
        ):
            fail("routing.json 写入后线程 ID 不一致")

        commit = commit_changes(project, TEXT_FILES)
    except BaseException:
        if commit is None:
            subprocess.run(
                ["git", "-C", str(project), "restore", "--staged", "--", *TEXT_FILES],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        restore_files(original)
        raise

    synced = sync_clones(project, commit)
    print(f"BOUND developer={developer} tester={tester}")
    print(f"COMMITTED {commit}")
    for role, clone_head in synced.items():
        print(f"SYNCED {role}={clone_head}")
    print(f"BACKUP {backup_root}")
    print("NEXT 在 Codex 中打开两个线程并分别设置为 deepseek-flash / max")
    print("所有线程完成首轮设置后运行 40-verify.command")


if __name__ == "__main__":
    main()
