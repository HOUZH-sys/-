#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

require_macos
for name in git curl jq shasum tar; do
  need "$name"
done

if ! xcode-select -p >/dev/null 2>&1; then
  fail "请先运行 xcode-select --install，完成后再执行本步骤"
fi
[ -f "$REPOSITORY_BUNDLE" ] || fail "缺少项目 bundle: $REPOSITORY_BUNDLE"
[ -f "$VERSIONS_FILE" ] || fail "缺少版本清单"

expected_commit="$(version_value '.repository.commit')"
actual_bundle_commit="$(bundle_commit)"
[ -n "$actual_bundle_commit" ] || fail "项目 bundle 中没有 main"
[ "$actual_bundle_commit" = "$expected_commit" ] ||
  fail "项目 bundle 提交与版本清单不一致"

if [ -e "$PROJECT_ROOT" ] && [ -n "$(ls -A "$PROJECT_ROOT" 2>/dev/null)" ]; then
  [ -d "$PROJECT_ROOT/.git" ] ||
    fail "项目路径非空且不是 Git 克隆；请先备份并移走: $PROJECT_ROOT"
else
  mkdir -p "$(dirname "$PROJECT_ROOT")"
  log "CLONE $PROJECT_ROOT"
  git clone "$REPOSITORY_BUNDLE" "$PROJECT_ROOT"
fi

git -C "$PROJECT_ROOT" merge-base --is-ancestor "$expected_commit" HEAD ||
  fail "现有项目不包含基线提交 $expected_commit"

case "$(uname -m)" in
  x86_64) uv_arch=x86_64 ;;
  arm64) uv_arch=arm64 ;;
  *) fail "不支持的 CPU 架构: $(uname -m)" ;;
esac

uv_version="$(version_value '.uv.version')"
uv_asset="$(version_value ".uv.${uv_arch}.asset")"
uv_sha="$(version_value ".uv.${uv_arch}.sha256")"
uv_dir="$PROJECT_ROOT/.tools/bin"
uv_cache="$PROJECT_ROOT/.tools/cache/downloads"
mkdir -p "$uv_dir" "$uv_cache" "$PROJECT_ROOT/.tools/uv/python"
chmod 700 "$PROJECT_ROOT/.tools" "$uv_dir" "$PROJECT_ROOT/.tools/cache" \
  "$uv_cache" "$PROJECT_ROOT/.tools/uv" "$PROJECT_ROOT/.tools/uv/python"

uv_archive="$uv_cache/$uv_asset"
download_verified \
  "https://github.com/astral-sh/uv/releases/download/$uv_version/$uv_asset" \
  "$uv_sha" 256 "$uv_archive"

if [ ! -x "$uv_dir/uv" ] || [ "$("$uv_dir/uv" --version | awk '{print $2}')" != "$uv_version" ]; then
  temp_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-uv.XXXXXX")"
  trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
  tar -xzf "$uv_archive" -C "$temp_dir"
  cp -p "$temp_dir/${uv_asset%.tar.gz}/uv" "$uv_dir/uv"
  chmod 755 "$uv_dir/uv"
  rm -rf "$temp_dir"
  trap - EXIT HUP INT TERM
fi

export UV_PYTHON_INSTALL_DIR="$HOME/.local/share/uv/python"
export UV_TOOL_DIR="$HOME/.local/share/uv/tools"
export UV_TOOL_BIN_DIR="$HOME/.local/bin"
export UV_CACHE_DIR="$HOME/.cache/uv"
mkdir -p "$UV_PYTHON_INSTALL_DIR" "$UV_TOOL_DIR" "$UV_TOOL_BIN_DIR" "$UV_CACHE_DIR"

headroom_version="$(version_value '.headroom.version')"
headroom_python_version="$(version_value '.headroom.python')"
cryptography_version="$(version_value '.headroom.cryptography')"
log "INSTALL Headroom $headroom_version"
"$uv_dir/uv" tool install \
  "headroom-ai==$headroom_version" \
  --python "$headroom_python_version" \
  --with "cryptography==$cryptography_version" \
  --no-progress

[ -x "$HOME/.local/bin/headroom" ] || fail "Headroom CLI 安装后不可执行"
[ -x "$(headroom_python)" ] || fail "Headroom Python 运行环境缺失"

prepare_archive() {
  archive="$1"
  temp_root="$2"
  [ -f "$archive" ] || fail "缺少离线资源: $archive"
  if tar -tzf "$archive" | awk '
    /^\// || /(^|\/)\.\.(\/|$)/ { bad = 1 }
    END { exit bad ? 0 : 1 }
  '; then
    fail "离线资源包含不安全路径: $archive"
  fi
  mkdir -p "$temp_root"
  tar -xzf "$archive" -C "$temp_root"
}

install_superpowers() {
  version="$(version_value '.skills.superpowers.version')"
  destination="$CODEX_HOME/plugins/cache/superpowers-dev/superpowers/$version"
  if [ -f "$destination/.codex-plugin/plugin.json" ] &&
    jq -e --arg version "$version" '.version == $version' \
      "$destination/.codex-plugin/plugin.json" >/dev/null 2>&1; then
    log "CACHED Superpowers $version"
    return
  fi
  [ ! -e "$destination" ] ||
    fail "Superpowers 目标目录存在但版本未知，请检查后移走: $destination"
  temp_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-superpowers.XXXXXX")"
  trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
  prepare_archive "$PACKAGE_ROOT/payload/superpowers-7.0.1.tar.gz" "$temp_dir/source"
  [ -f "$temp_dir/source/.codex-plugin/plugin.json" ] ||
    fail "Superpowers 离线包结构不完整"
  mkdir -p "$(dirname "$destination")"
  ditto "$temp_dir/source" "$destination"
  chmod -R u+rwX,go-rwx "$destination"
  rm -rf "$temp_dir"
  trap - EXIT HUP INT TERM
  log "INSTALLED Superpowers $version"
}

install_awesome_skills() {
  commit="$(version_value '.skills.awesome_gamedev.commit')"
  marker="$CODEX_HOME/skills/.awesome-gamedev-looped-vows.json"
  if [ -f "$marker" ] &&
    jq -e --arg commit "$commit" '.commit == $commit' "$marker" >/dev/null 2>&1; then
    count="$(find "$CODEX_HOME/skills" -maxdepth 2 -name SKILL.md | wc -l | tr -d ' ')"
    [ "$count" -ge 77 ] || fail "awesome-gamedev 标记存在但技能文件少于 77 个"
    log "CACHED awesome-gamedev $commit skills=$count"
    return
  fi

  [ ! -e "$CODEX_HOME/skills/router" ] ||
    fail "已有同名 router 技能且没有本交付包标记；为避免覆盖用户技能，请先人工核对"
  temp_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-skills.XXXXXX")"
  trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
  prepare_archive \
    "$PACKAGE_ROOT/payload/awesome-gamedev-19d93f97c9c1ea0f8b306e77aa81e0d3e352d3e9.tar.gz" \
    "$temp_dir/source"
  source_root="$temp_dir/source"
  [ -f "$source_root/router/SKILL.md" ] || fail "awesome-gamedev router 缺失"
  count="$(
    find "$source_root/skills" -mindepth 3 -maxdepth 3 -name SKILL.md |
      wc -l | tr -d ' '
  )"
  [ "$count" -eq 77 ] || fail "awesome-gamedev 离线包应有 77 个技能，实际 $count"
  mkdir -p "$CODEX_HOME/skills"
  while IFS= read -r skill_md; do
    skill_dir="$(dirname "$skill_md")"
    name="$(basename "$skill_dir")"
    [ ! -e "$CODEX_HOME/skills/$name" ] ||
      fail "已有同名技能 $name；为避免覆盖用户技能，请先人工核对"
  done < <(
    find "$source_root/skills" -mindepth 3 -maxdepth 3 \
      -name SKILL.md -print | sort
  )
  for name in router; do
    [ ! -e "$CODEX_HOME/skills/$name" ] ||
      fail "已有同名技能 $name；为避免覆盖用户技能，请先人工核对"
    ditto "$source_root/$name" "$CODEX_HOME/skills/$name"
  done
  while IFS= read -r skill_md; do
    skill_dir="$(dirname "$skill_md")"
    name="$(basename "$skill_dir")"
    ditto "$skill_dir" "$CODEX_HOME/skills/$name"
  done < <(
    find "$source_root/skills" -mindepth 3 -maxdepth 3 \
      -name SKILL.md -print | sort
  )
  jq -n \
    --arg commit "$commit" \
    --arg source "$(version_value '.skills.awesome_gamedev.source')" \
    --arg installed_at "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
    '{schema_version:1, commit:$commit, source:$source, skill_count:77, installed_at:$installed_at}' \
    > "$marker"
  chmod 600 "$marker"
  rm -rf "$temp_dir"
  trap - EXIT HUP INT TERM
  log "INSTALLED awesome-gamedev $commit skills=77"
}

install_superpowers
install_awesome_skills

mkdir -p "$PROJECT_ROOT/.game-auto/agent-round"
for role in developer tester; do
  workspace="$PROJECT_ROOT/.game-auto/agent-round/$role"
  if [ ! -e "$workspace" ]; then
    git clone --no-hardlinks "$PROJECT_ROOT" "$workspace"
  else
    ensure_clean_git_clone "$workspace"
  fi
  if [ ! -e "$workspace/.tools" ]; then
    ln -s ../../../.tools "$workspace/.tools"
  elif [ ! -L "$workspace/.tools" ]; then
    warn "$role 克隆已有实体 .tools，保留现状"
  fi
  if [ -d "$PROJECT_ROOT/godot-native" ] && [ ! -e "$workspace/godot-native" ]; then
    ln -s ../../../godot-native "$workspace/godot-native"
  fi
done

log "PASS bootstrap repository=$(repository_commit "$PROJECT_ROOT")"
log "NEXT 运行 20-install-project.command"
