#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

require_macos
ensure_clean_git_clone "$PROJECT_ROOT"
activate_project_path

"$PACKAGE_ROOT/scripts/verify-package.sh"

[ -d /Applications/ChatGPT.app ] || fail "ChatGPT Desktop 未安装"
[ -d "$CODEX_HOME/computer-use/Codex Computer Use.app" ] ||
  fail "Codex Computer Use 未安装"
[ -f "$CODEX_HOME/config.toml" ] || fail "Codex 配置不存在"

python_bin="$(python_command)"
"$python_bin" "$PACKAGE_ROOT/scripts/configure-codex-route.py" --check

godot_bin="$PROJECT_ROOT/.tools/godot/4.7.2-stable/Godot.app/Contents/MacOS/Godot"
[ -x "$godot_bin" ] || fail "Godot 未安装"
[ "$("$godot_bin" --version)" = "$(version_value '.godot.version_full')" ] ||
  fail "Godot 版本不匹配"

node_bin="$PROJECT_ROOT/.tools/node/v24.22.0/bin/node"
[ -x "$node_bin" ] || fail "Node.js 未安装"
[ "$("$node_bin" --version)" = "v$(version_value '.node.version')" ] ||
  fail "Node.js 版本不匹配"

for role in developer tester; do
  workspace="$PROJECT_ROOT/.game-auto/agent-round/$role"
  [ -d "$workspace/.git" ] || fail "$role 独立克隆缺失"
  [ -L "$workspace/.tools" ] || fail "$role 克隆缺少 .tools 链接"
done

[ -x "$HOME/.local/bin/headroom" ] || fail "Headroom 未安装"
"$PROJECT_ROOT/automation/headroom/headroom-control.sh" ensure
"$PROJECT_ROOT/automation/headroom/headroom-control.sh" verify

"$PROJECT_ROOT/automation/native-agents/skill-stack.sh"
"$PROJECT_ROOT/automation/devtools/verify.sh"
"$PROJECT_ROOT/automation/headroom/headroom-control.test.sh"
"$PROJECT_ROOT/automation/nightshift/native-cua-result-validator.test.sh"
"$PROJECT_ROOT/automation/nightshift/longrun-control.test.sh"
"$PROJECT_ROOT/automation/nightshift/work-conservation.test.sh"
"$PROJECT_ROOT/automation/nightshift/host-lifecycle.test.sh"
"$PROJECT_ROOT/automation/nightshift/resource-lanes.test.sh"
"$PROJECT_ROOT/automation/native-agents/capability-workflow.test.sh"

log "VERIFY project check suite"
"$PROJECT_ROOT/godot-court/check.sh"

log "VERIFY clean local build"
build_root="$PROJECT_ROOT/.game-auto/new-mac-smoke"
rm -rf "$build_root"
"$PROJECT_ROOT/automation/godot/build.sh" "$build_root" >/dev/null
manifest="$(find "$build_root" -mindepth 2 -maxdepth 2 -name manifest.json -print | head -n 1)"
[ -n "$manifest" ] || fail "本地构建清单缺失"
jq -e \
  --arg sha "$(repository_commit "$PROJECT_ROOT")" \
  '.source_sha == $sha and .source_clean == true' "$manifest" >/dev/null ||
  fail "本地构建与当前提交不一致"

log "VERIFY native routing preflight"
"$PROJECT_ROOT/automation/native-agents/preflight.sh"

log "PASS new-mac-verification"
log "人工最后检查：原生 Computer Use 首次启动时必须通过 macOS 辅助功能与屏幕录制授权。"
