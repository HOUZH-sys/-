#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

manifest="$PACKAGE_ROOT/MANIFEST.sha256"
[ -f "$manifest" ] || fail "缺少包清单: $manifest"

log "VERIFY package checksums"
(
  cd "$PACKAGE_ROOT"
  shasum -a 256 -c MANIFEST.sha256
)

log "VERIFY shell syntax"
while IFS= read -r file; do
  bash -n "$file"
done < <(
  find "$PACKAGE_ROOT" -type f \
    \( -name '*.sh' -o -name '*.command' \) \
    -not -path '*/manual/*' -print |
    sort
)

python_bin="$(python_command)"
log "VERIFY Python syntax"
while IFS= read -r file; do
  "$python_bin" -m py_compile "$file"
done < <(find "$PACKAGE_ROOT/scripts" -type f -name '*.py' -print | sort)
find "$PACKAGE_ROOT/scripts" -type d -name __pycache__ -prune -exec rm -rf {} +

log "VERIFY JSON"
while IFS= read -r file; do
  jq empty "$file"
done < <(find "$PACKAGE_ROOT/config" -type f -name '*.json' -print | sort)

log "VERIFY repository bundle"
bundle_check="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-bundle-check.XXXXXX")"
if ! git init -q --bare "$bundle_check" ||
  ! git -C "$bundle_check" bundle verify "$REPOSITORY_BUNDLE" >/dev/null; then
  rm -rf "$bundle_check"
  fail "项目 bundle 无法在空仓库中验证"
fi
rm -rf "$bundle_check"
[ "$(bundle_commit)" = "$(version_value '.repository.commit')" ] ||
  fail "项目 bundle 提交不匹配"

secret_hits="$(
  rg -n -i \
    'BEGIN (RSA|OPENSSH|EC|DSA) PRIVATE KEY|sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{20,}' \
    "$PACKAGE_ROOT/scripts" "$PACKAGE_ROOT/config" \
    "$PACKAGE_ROOT"/*.command "$PACKAGE_ROOT"/*.txt 2>/dev/null || true
)"
[ -z "$secret_hits" ] || fail "静态扫描发现疑似凭证"

if find "$PACKAGE_ROOT" -type f \
  \( -name '.env' -o -name 'auth.json' -o -name 'credentials.json' \
     -o -name '*.pem' -o -name '*.key' \) -print | grep -q .; then
  fail "包内出现凭证类文件"
fi

log "VERIFY offline skill payloads"
superpowers_tmp="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-check-superpowers.XXXXXX")"
awesome_tmp="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-check-awesome.XXXXXX")"
trap 'rm -rf "$superpowers_tmp" "$awesome_tmp"' EXIT HUP INT TERM
tar -xzf "$PACKAGE_ROOT/payload/superpowers-7.0.1.tar.gz" -C "$superpowers_tmp"
jq -e '.version == "7.0.1"' "$superpowers_tmp/.codex-plugin/plugin.json" >/dev/null
tar -xzf \
  "$PACKAGE_ROOT/payload/awesome-gamedev-19d93f97c9c1ea0f8b306e77aa81e0d3e352d3e9.tar.gz" \
  -C "$awesome_tmp"
[ -f "$awesome_tmp/router/SKILL.md" ] || fail "awesome-gamedev router 缺失"
skill_count="$(
  find "$awesome_tmp/skills" -mindepth 3 -maxdepth 3 -name SKILL.md |
    wc -l | tr -d ' '
)"
[ "$skill_count" -eq 77 ] || fail "awesome-gamedev 技能数不是 77"
skill_names="$(
  find "$awesome_tmp/skills" -mindepth 3 -maxdepth 3 -name SKILL.md -print |
    while IFS= read -r skill_md; do
      basename "$(dirname "$skill_md")"
    done |
    sort
)"
[ "$(printf '%s\n' "$skill_names" | sort -u | sed '/^$/d' | wc -l | tr -d ' ')" -eq 77 ] ||
  fail "awesome-gamedev 技能目录名存在重复或为空"

flattened="$awesome_tmp/flattened"
mkdir -p "$flattened"
while IFS= read -r skill_md; do
  skill_dir="$(dirname "$skill_md")"
  cp -R "$skill_dir" "$flattened/$(basename "$skill_dir")"
done < <(
  find "$awesome_tmp/skills" -mindepth 3 -maxdepth 3 -name SKILL.md -print |
    sort
)
[ "$(
  find "$flattened" -mindepth 2 -maxdepth 2 -name SKILL.md |
    wc -l | tr -d ' '
)" -eq 77 ] || fail "awesome-gamedev 无法展平为 Codex 技能目录"

"$PACKAGE_ROOT/scripts/tests/route-test.sh"
"$PACKAGE_ROOT/scripts/tests/bind-threads-test.sh"

log "PASS package-integrity"
