#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

require_macos
ensure_clean_git_clone "$PROJECT_ROOT"
[ -f "$CODEX_HOME/config.toml" ] ||
  fail "缺少 $CODEX_HOME/config.toml；先启动 ChatGPT Desktop 并登录"

headroom_cli="$HOME/.local/bin/headroom"
[ -x "$headroom_cli" ] ||
  fail "Headroom 尚未安装；请先运行 10-bootstrap.command"

log "1/4 创建受管 Headroom deployment，不替换 DeepSeek provider"
"$headroom_cli" install apply \
  --preset persistent-service \
  --runtime python \
  --scope user \
  --providers manual \
  --profile codex-deepseek \
  --port 8787 \
  --backend anthropic \
  --mode cache \
  --no-telemetry \
  --no-rate-limit \
  --no-http2 \
  --env OPENAI_TARGET_API_URL=https://api.deepseek.com \
  --env HEADROOM_BEACON=off \
  --env DO_NOT_TRACK=1

log "2/4 启用 Superpowers、游戏与 Product Design 插件"
python_bin="$(python_command)"
"$python_bin" "$PACKAGE_ROOT/scripts/configure-codex-route.py" --apply

log "3/4 安装安全 loopback gateway 并启动代理"
"$PROJECT_ROOT/automation/headroom/headroom-control.sh" ensure

log "4/4 验证隐私、路由与 gateway"
"$PROJECT_ROOT/automation/headroom/headroom-control.sh" verify

log "PASS codex-routing"
log "请完全退出并重新打开 ChatGPT Desktop，使插件和模型配置生效。"
