#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
import tempfile
import tomllib
from datetime import datetime, timezone
from pathlib import Path

BASE_URL = "http://127.0.0.1:8787/v1"
PROVIDER = "deepseek"
MODEL = "deepseek-flash"
EFFORT = "max"
SUPERPOWERS_SOURCE = "https://github.com/obra/superpowers.git"
SUPERPOWERS_REF = "v7.0.1"
REQUIRED_PLUGINS = (
    "superpowers@superpowers-dev",
    "game-studio@openai-api-curated",
    "product-design@openai-api-curated",
    "computer-use@openai-bundled",
    "unified-computer-use@openai-bundled",
)


def fail(message: str) -> None:
    print(f"FAIL codex-route: {message}", file=sys.stderr)
    raise SystemExit(1)


def section_bounds(lines: list[str], section: str) -> tuple[int, int] | None:
    header = f"[{section}]"
    for index, line in enumerate(lines):
        if line.strip() == header:
            end = len(lines)
            for cursor in range(index + 1, len(lines)):
                if lines[cursor].lstrip().startswith("["):
                    end = cursor
                    break
            return index, end
    return None


def ensure_section(lines: list[str], section: str) -> None:
    if section_bounds(lines, section) is not None:
        return
    if lines and not lines[-1].endswith("\n"):
        lines[-1] += "\n"
    if lines and lines[-1].strip():
        lines.append("\n")
    lines.append(f"[{section}]\n")


def set_key_in_section(
    lines: list[str], section: str, key: str, rendered: str
) -> None:
    ensure_section(lines, section)
    bounds = section_bounds(lines, section)
    assert bounds is not None
    start, end = bounds
    pattern = re.compile(rf"^\s*{re.escape(key)}\s*=")
    matches = [index for index in range(start + 1, end) if pattern.match(lines[index])]
    if len(matches) > 1:
        fail(f"duplicate key {key} in [{section}]")
    if matches:
        lines[matches[0]] = f"{key} = {rendered}\n"
    else:
        lines.insert(end, f"{key} = {rendered}\n")


def set_top_level(lines: list[str], key: str, rendered: str) -> None:
    first_section = len(lines)
    for index, line in enumerate(lines):
        if line.lstrip().startswith("["):
            first_section = index
            break
    pattern = re.compile(rf"^\s*{re.escape(key)}\s*=")
    matches = [index for index in range(first_section) if pattern.match(lines[index])]
    if len(matches) > 1:
        fail(f"duplicate top-level key {key}")
    if matches:
        lines[matches[0]] = f"{key} = {rendered}\n"
    else:
        lines.insert(first_section, f"{key} = {rendered}\n")


def config_path() -> Path:
    codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
    return Path(os.environ.get("HEADROOM_CONFIG_PATH", codex_home / "config.toml"))


def headroom_python() -> Path:
    configured = os.environ.get("HEADROOM_CONFIG_PYTHON")
    if configured:
        return Path(configured).expanduser()
    return Path.home() / ".local/share/uv/tools/headroom-ai/bin/python"


def load_toml(path: Path) -> dict:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        fail(f"Codex config is missing: {path}; launch ChatGPT Desktop and sign in first")
    except Exception as exc:
        fail(f"Codex config is not valid TOML: {exc}")


def plugin_enabled(config: dict, plugin: str) -> bool:
    value = config.get("plugins", {}).get(plugin)
    return isinstance(value, dict) and value.get("enabled") is True


def route_checks(config: dict) -> dict[str, bool]:
    provider = config.get("model_providers", {}).get(PROVIDER, {})
    mcp = config.get("mcp_servers", {}).get("headroom", {})
    return {
        "provider": config.get("model_provider") == PROVIDER,
        "model": config.get("model") == MODEL,
        "reasoning": config.get("model_reasoning_effort") == EFFORT,
        "base_url": provider.get("base_url") == BASE_URL,
        "wire_api": provider.get("wire_api") == "responses",
        "websockets": provider.get("supports_websockets") is False,
        "credential": bool(
            provider.get("experimental_bearer_token") or provider.get("env_key")
        ),
        "mcp": (
            isinstance(mcp, dict)
            and mcp.get("command") == str(headroom_python().expanduser())
            and mcp.get("args") == ["-m", "headroom.cli", "mcp", "serve"]
        ),
        "superpowers_marketplace": (
            config.get("marketplaces", {}).get("superpowers-dev", {}).get("source")
            == SUPERPOWERS_SOURCE
        ),
        "plugins": all(plugin_enabled(config, plugin) for plugin in REQUIRED_PLUGINS),
    }


def check(path: Path) -> None:
    config = load_toml(path)
    checks = route_checks(config)
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        fail("route mismatch: " + ",".join(failed))
    print(
        f"PASS codex-route provider={PROVIDER} model={MODEL} "
        f"reasoning={EFFORT} base_url={BASE_URL}"
    )


def apply(path: Path) -> None:
    config = load_toml(path)
    provider = config.get("model_providers", {}).get(PROVIDER, {})
    if not isinstance(provider, dict):
        fail(f"[model_providers.{PROVIDER}] is malformed")
    if not (provider.get("experimental_bearer_token") or provider.get("env_key")):
        fail(
            f"configure the {PROVIDER} credential in Codex first; "
            "this package never creates or prints credentials"
        )
    if not headroom_python().is_file():
        fail("Headroom Python runtime is missing; run 10-bootstrap.command first")

    text = path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    if section_bounds(lines, f"model_providers.{PROVIDER}") is None:
        fail(f"missing [model_providers.{PROVIDER}]")

    set_top_level(lines, "model", f'"{MODEL}"')
    set_top_level(lines, "model_provider", f'"{PROVIDER}"')
    set_top_level(lines, "model_reasoning_effort", f'"{EFFORT}"')
    set_key_in_section(
        lines, f"model_providers.{PROVIDER}", "base_url", f'"{BASE_URL}"'
    )
    set_key_in_section(
        lines, f"model_providers.{PROVIDER}", "wire_api", '"responses"'
    )
    set_key_in_section(
        lines, f"model_providers.{PROVIDER}", "supports_websockets", "false"
    )

    set_key_in_section(
        lines, "marketplaces.superpowers-dev", "source_type", '"git"'
    )
    set_key_in_section(
        lines, "marketplaces.superpowers-dev", "source", f'"{SUPERPOWERS_SOURCE}"'
    )
    set_key_in_section(
        lines, "marketplaces.superpowers-dev", "ref", f'"{SUPERPOWERS_REF}"'
    )
    for plugin in REQUIRED_PLUGINS:
        set_key_in_section(lines, f'plugins."{plugin}"', "enabled", "true")

    set_key_in_section(
        lines, "mcp_servers.headroom", "command", f'"{headroom_python()}"'
    )
    set_key_in_section(
        lines,
        "mcp_servers.headroom",
        "args",
        '["-m", "headroom.cli", "mcp", "serve"]',
    )

    new_text = "".join(lines)
    try:
        parsed = tomllib.loads(new_text)
    except Exception as exc:
        fail(f"generated config is invalid: {exc}")
    failed = [name for name, passed in route_checks(parsed).items() if not passed]
    if failed:
        fail("generated route mismatch: " + ",".join(failed))

    backup = path.with_name(path.name + ".before-looped-vows-new-machine")
    if not backup.exists():
        shutil.copy2(path, backup)
        backup.chmod(0o600)

    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(new_text)
        os.chmod(temp_name, 0o600)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)

    check(path)
    print(f"BACKUP {backup}")


def rollback(path: Path) -> None:
    backup = path.with_name(path.name + ".before-looped-vows-new-machine")
    if not backup.is_file():
        fail(f"rollback backup is missing: {backup}")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    current_backup = path.with_name(path.name + f".before-rollback-{stamp}")
    shutil.copy2(path, current_backup)
    current_backup.chmod(0o600)
    shutil.copy2(backup, path)
    path.chmod(0o600)
    print(f"RESTORED {path}")
    print(f"PRE_ROLLBACK_BACKUP {current_backup}")


def main() -> None:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--rollback", action="store_true")
    args = parser.parse_args()
    path = config_path()

    if args.check:
        check(path)
    elif args.apply:
        apply(path)
    else:
        rollback(path)


if __name__ == "__main__":
    main()
