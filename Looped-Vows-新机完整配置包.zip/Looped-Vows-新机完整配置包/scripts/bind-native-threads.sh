#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

python_bin="$(python_command)"
if [ "$#" -eq 2 ]; then
  developer="$1"
  tester="$2"
else
  printf 'Developer thread ID: '
  read -r developer
  printf 'Tester thread ID: '
  read -r tester
fi

"$python_bin" "$PACKAGE_ROOT/scripts/bind-native-threads.py" \
  --project "$PROJECT_ROOT" \
  --developer "$developer" \
  --tester "$tester" \
  --apply
