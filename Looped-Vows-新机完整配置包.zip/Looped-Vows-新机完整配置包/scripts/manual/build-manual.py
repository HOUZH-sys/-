#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
DOCS_DIR = PACKAGE_ROOT / "docs"
MANUAL_DIR = PACKAGE_ROOT / "手册"
ASSET_DIR = DOCS_DIR / "assets"
VERSIONS = json.loads((PACKAGE_ROOT / "config/versions.json").read_text("utf-8"))

FONT_BODY = "Hiragino Sans GB"
FONT_CJK = "Hiragino Sans GB"
FONT_MONO = "Menlo"
INK = RGBColor(28, 35, 42)
MUTED = RGBColor(82, 94, 105)
NAVY = RGBColor(31, 67, 96)
ACCENT = RGBColor(43, 111, 133)
RULE = "C9D1D7"
HEADER_FILL = "DDE5EA"
ALT_FILL = "F4F6F7"


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=110, bottom=90, end=110) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_run_font(run, name: str, east_asia: str = FONT_CJK, size=None, bold=None, color=None) -> None:
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east_asia)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = color


def set_paragraph_border(paragraph, position: str, color: str = RULE, size: int = 8) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    borders = p_pr.find(qn("w:pBdr"))
    if borders is None:
        borders = OxmlElement("w:pBdr")
        p_pr.append(borders)
    edge = OxmlElement(f"w:{position}")
    edge.set(qn("w:val"), "single")
    edge.set(qn("w:sz"), str(size))
    edge.set(qn("w:space"), "4")
    edge.set(qn("w:color"), color)
    borders.append(edge)


def clear_style_borders(style) -> None:
    p_pr = style.element.get_or_add_pPr()
    for border in list(p_pr.findall(qn("w:pBdr"))):
        p_pr.remove(border)


def add_page_number(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("第 ")
    set_run_font(run, FONT_BODY, size=8.5, color=MUTED)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(begin)
    run._r.append(instr)
    run._r.append(end)
    run.add_text(" 页")
    set_run_font(run, FONT_BODY, size=8.5, color=MUTED)


def configure_styles(doc: Document) -> None:
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = FONT_BODY
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = INK
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.16

    title = styles["Title"]
    title.font.name = FONT_BODY
    title._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)
    title.font.size = Pt(28)
    title.font.bold = True
    title.font.color.rgb = RGBColor(0, 0, 0)
    title.paragraph_format.space_before = Pt(76)
    title.paragraph_format.space_after = Pt(18)
    clear_style_borders(title)

    subtitle = styles["Subtitle"]
    subtitle.font.name = FONT_BODY
    subtitle._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)
    subtitle.font.size = Pt(14)
    subtitle.font.color.rgb = MUTED
    subtitle.paragraph_format.space_after = Pt(20)
    clear_style_borders(subtitle)

    for name, size, before, after in (
        ("Heading 1", 17, 18, 8),
        ("Heading 2", 13, 14, 6),
        ("Heading 3", 11.5, 10, 4),
    ):
        style = styles[name]
        style.font.name = FONT_BODY
        style._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = NAVY
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    if "Code Block" not in styles:
        code = styles.add_style("Code Block", WD_STYLE_TYPE.PARAGRAPH)
        code.base_style = styles["Normal"]
    code = styles["Code Block"]
    code.font.name = FONT_MONO
    code._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)
    code.font.size = Pt(8.5)
    code.font.color.rgb = RGBColor(35, 42, 48)
    code.paragraph_format.left_indent = Inches(0.18)
    code.paragraph_format.right_indent = Inches(0.12)
    code.paragraph_format.space_before = Pt(4)
    code.paragraph_format.space_after = Pt(7)
    code.paragraph_format.line_spacing = 1.05

    if "Figure Caption" not in styles:
        caption = styles.add_style("Figure Caption", WD_STYLE_TYPE.PARAGRAPH)
        caption.base_style = styles["Normal"]
    caption = styles["Figure Caption"]
    caption.font.name = FONT_BODY
    caption._element.rPr.rFonts.set(qn("w:eastAsia"), FONT_CJK)
    caption.font.size = Pt(8.5)
    caption.font.italic = True
    caption.font.color.rgb = MUTED
    caption.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    caption.paragraph_format.space_before = Pt(2)
    caption.paragraph_format.space_after = Pt(9)

    for section in doc.sections:
        section.top_margin = Inches(0.72)
        section.bottom_margin = Inches(0.68)
        section.left_margin = Inches(0.78)
        section.right_margin = Inches(0.78)


def add_header_footer(doc: Document) -> None:
    section = doc.sections[0]
    section.different_first_page_header_footer = True
    header = section.header
    paragraph = header.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("LOOPED VOWS  /  NEW MAC SETUP")
    set_run_font(run, FONT_BODY, east_asia=FONT_CJK, size=8, bold=True, color=MUTED)
    set_paragraph_border(paragraph, "bottom")
    add_page_number(section.footer.paragraphs[0])


def add_heading(doc: Document, text: str, level=1) -> None:
    paragraph = doc.add_heading(text, level=level)
    paragraph.paragraph_format.keep_with_next = True


def add_paragraph(doc: Document, text: str, *, bold_lead: str | None = None):
    paragraph = doc.add_paragraph()
    if bold_lead:
        run = paragraph.add_run(bold_lead)
        set_run_font(run, FONT_BODY, size=10.5, bold=True, color=INK)
    run = paragraph.add_run(text)
    set_run_font(run, FONT_BODY, size=10.5, color=INK)
    return paragraph


def add_bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        paragraph = doc.add_paragraph(style="List Bullet")
        paragraph.paragraph_format.space_after = Pt(3)
        paragraph.add_run(item)


def add_code(doc: Document, text: str) -> None:
    paragraph = doc.add_paragraph(style="Code Block")
    paragraph.paragraph_format.keep_together = True
    set_paragraph_border(paragraph, "left", color="8EA8B6", size=18)
    run = paragraph.add_run(text)
    set_run_font(run, FONT_MONO, size=8.5, color=RGBColor(35, 42, 48))


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = False if widths else True
    header = table.rows[0]
    set_repeat_table_header(header)
    prevent_row_split(header)
    for index, text in enumerate(headers):
        cell = header.cells[index]
        cell.text = ""
        para = cell.paragraphs[0]
        para.paragraph_format.space_after = Pt(0)
        run = para.add_run(text)
        set_run_font(run, FONT_BODY, size=9, bold=True, color=INK)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_shading(cell, HEADER_FILL)
        set_cell_margins(cell)
        if widths:
            cell.width = Inches(widths[index])

    for row_index, values in enumerate(rows):
        row = table.add_row()
        prevent_row_split(row)
        for index, text in enumerate(values):
            cell = row.cells[index]
            cell.text = ""
            para = cell.paragraphs[0]
            para.paragraph_format.space_after = Pt(0)
            run = para.add_run(text)
            set_run_font(run, FONT_BODY, size=8.8, color=INK)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            if row_index % 2:
                set_cell_shading(cell, ALT_FILL)
            if widths:
                cell.width = Inches(widths[index])
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def add_figure(doc: Document, image_path: Path, caption: str, width=6.55) -> None:
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.keep_with_next = True
    paragraph.add_run().add_picture(str(image_path), width=Inches(width))
    caption_para = doc.add_paragraph(style="Figure Caption")
    caption_para.add_run(caption)


def load_font(size: int, bold=False) -> ImageFont.FreeTypeFont:
    candidates = [
        Path("/System/Library/Fonts/STHeiti Medium.ttc") if bold else
        Path("/System/Library/Fonts/STHeiti Light.ttc"),
        Path("/Library/Fonts/Arial Unicode.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def centered_text(draw, box, text, font, fill="#1C232A", max_width=None):
    x1, y1, x2, y2 = box
    lines = text.split("\n")
    heights = []
    widths = []
    for line in lines:
        bounds = draw.textbbox((0, 0), line, font=font)
        widths.append(bounds[2] - bounds[0])
        heights.append(bounds[3] - bounds[1])
    total_h = sum(heights) + (len(lines) - 1) * 8
    y = y1 + (y2 - y1 - total_h) / 2
    for line, width, height in zip(lines, widths, heights):
        draw.text((x1 + (x2 - x1 - width) / 2, y), line, font=font, fill=fill)
        y += height + 8


def arrow(draw, start, end, fill="#50636F", width=4):
    draw.line([start, end], fill=fill, width=width)
    x1, y1 = start
    x2, y2 = end
    if abs(x2 - x1) >= abs(y2 - y1):
        direction = 1 if x2 > x1 else -1
        points = [(x2, y2), (x2 - 12 * direction, y2 - 7), (x2 - 12 * direction, y2 + 7)]
    else:
        direction = 1 if y2 > y1 else -1
        points = [(x2, y2), (x2 - 7, y2 - 12 * direction), (x2 + 7, y2 - 12 * direction)]
    draw.polygon(points, fill=fill)


def make_architecture() -> Path:
    path = ASSET_DIR / "architecture.png"
    image = Image.new("RGB", (1800, 1040), "#FFFFFF")
    draw = ImageDraw.Draw(image)
    f_title = load_font(38, True)
    f_box = load_font(30, True)
    f_body = load_font(24)
    f_small = load_font(21)
    dark = "#1C232A"
    border = "#5D7481"
    fill = "#F1F5F7"
    accent_fill = "#E1EDF2"

    boxes = {
        "codex": (90, 120, 520, 340),
        "plugins": (90, 430, 520, 650),
        "headroom": (660, 120, 1130, 340),
        "deepseek": (1320, 120, 1710, 340),
        "cua": (660, 430, 1130, 650),
        "game": (1320, 430, 1710, 650),
        "project": (90, 760, 520, 950),
        "guard": (660, 760, 1130, 950),
        "evidence": (1320, 760, 1710, 950),
    }
    for key, box in boxes.items():
        color = accent_fill if key in {"headroom", "cua"} else fill
        draw.rounded_rectangle(box, radius=24, fill=color, outline=border, width=3)

    centered_text(draw, boxes["codex"], "ChatGPT Desktop / Codex\nSupervisor", f_box, dark)
    centered_text(draw, boxes["plugins"], "固定能力栈\nSuperpowers 7.0.1\nProduct Design · Game Studio\nawesome-gamedev router", f_body, dark)
    centered_text(draw, boxes["headroom"], "Headroom 安全网关\n127.0.0.1:8787\nHost / Origin / JSON 校验\nTelemetry OFF", f_box, dark)
    centered_text(draw, boxes["deepseek"], "DeepSeek Provider\ndeepseek-flash\nreasoning = max", f_box, dark)
    centered_text(draw, boxes["cua"], "原生 Computer Use\nAX · 截图 · 鼠标 · 键盘\n不接管前台控制台", f_box, dark)
    centered_text(draw, boxes["game"], "隔离候选构建\nLoopedVows.app\n真实运行与状态变化", f_box, dark)
    centered_text(draw, boxes["project"], "主克隆\n项目固定工具链\nGodot · Node · uv · Aider", f_body, dark)
    centered_text(draw, boxes["guard"], "宿主与调度守卫\nAC · 开盖 · 精确 PID\nlease 与 deadline", f_body, dark)
    centered_text(draw, boxes["evidence"], "验收证据\n截图哈希 · AX 前后变化\nconsole 未变 · PID 清零", f_body, dark)

    arrow(draw, (520, 230), (660, 230))
    arrow(draw, (1130, 230), (1320, 230))
    arrow(draw, (520, 540), (660, 540))
    arrow(draw, (1130, 540), (1320, 540))
    arrow(draw, (305, 340), (305, 430))
    arrow(draw, (305, 650), (305, 760))
    arrow(draw, (520, 855), (660, 855))
    arrow(draw, (1130, 855), (1320, 855))
    arrow(draw, (1515, 650), (1515, 760))

    draw.text((92, 42), "恢复后的系统边界与数据流", font=f_title, fill=dark)
    draw.text((92, 1020), "代码路由与 GUI 验收是两条独立路径；二者共享可审计状态，但不共享旧 GUI 驱动。", font=f_small, fill="#52606A")
    image.save(path, quality=95)
    return path


def make_workflow() -> Path:
    path = ASSET_DIR / "workflow.png"
    image = Image.new("RGB", (1800, 650), "#FFFFFF")
    draw = ImageDraw.Draw(image)
    f_title = load_font(38, True)
    f_box = load_font(27, True)
    f_body = load_font(22)
    stages = [
        ("01", "只读体检", "版本、目录、旧组件\n失败不写入"),
        ("02", "基础环境", "项目 bundle、uv\nHeadroom、技能源"),
        ("03", "项目工具链", "Node、Godot、模板\n开发工具、双克隆"),
        ("04", "路由与授权", "DeepSeek、插件\nHeadroom、原生 CUA"),
        ("05", "端到端验收", "自动测试、构建\n路由 preflight"),
    ]
    x = 55
    boxes = []
    for number, title, body in stages:
        box = (x, 145, x + 305, 435)
        boxes.append(box)
        draw.rounded_rectangle(box, radius=22, fill="#F1F5F7", outline="#5D7481", width=3)
        draw.ellipse((x + 22, 168, x + 82, 228), fill="#2B6F85")
        centered_text(draw, (x + 22, 168, x + 82, 228), number, load_font(24, True), "#FFFFFF")
        centered_text(draw, (x + 25, 245, x + 280, 300), title, f_box)
        centered_text(draw, (x + 25, 315, x + 280, 410), body, f_body)
        if x + 305 < 1700:
            arrow(draw, (x + 305, 290), (x + 355, 290), width=3)
        x += 355
    draw.text((55, 45), "五阶段恢复流程", font=f_title, fill="#1C232A")
    draw.text((55, 520), "前三阶段可重复执行且幂等；第 4 阶段包含必须由用户完成的安全授权；第 5 阶段通过后才算迁移完成。", font=f_body, fill="#52606A")
    image.save(path, quality=95)
    return path


def add_cover(doc: Document) -> None:
    paragraph = doc.add_paragraph()
    run = paragraph.add_run("LOOPED VOWS")
    set_run_font(run, FONT_BODY, size=10, bold=True, color=ACCENT)
    paragraph.paragraph_format.space_before = Pt(18)
    doc.add_paragraph()
    title = doc.add_paragraph(style="Title")
    title.add_run("Looped Vows 新 Mac 配置与迁移手册")
    subtitle = doc.add_paragraph(style="Subtitle")
    subtitle.add_run("从空白 macOS 到可验证的原生 Computer Use 开发环境")
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(26)
    run = paragraph.add_run("适用对象")
    set_run_font(run, FONT_BODY, size=10, bold=True, color=MUTED)
    paragraph = doc.add_paragraph(
        "需要复刻 Looped Vows 开发、调度、代理与 GUI 验收集成的机器所有者或维护者。"
    )
    paragraph.paragraph_format.space_after = Pt(22)

    add_table(
        doc,
        ["交付信息", "值"],
        [
            ["基线日期", VERSIONS["baseline"]["captured_at"]],
            ["项目提交", VERSIONS["repository"]["commit"][:12]],
            ["目标系统", "macOS 15 或更新；Intel / Apple Silicon"],
            ["产品 GUI", "Codex 原生 Computer Use"],
            ["模型路由", "deepseek / deepseek-flash / max"],
            ["交付原则", "可复现、失败关闭、不携带凭证"],
        ],
        [1.55, 5.25],
    )
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(26)
    run = paragraph.add_run(
        "结论先行：新机器应恢复的是可验证的运行契约，不复制旧账户、旧 GUI 夹具或本机缓存。"
    )
    set_run_font(run, FONT_BODY, size=11, bold=True, color=INK)
    doc.add_page_break()


def add_executive_section(doc: Document, architecture: Path) -> None:
    add_heading(doc, "1 目标与最终形态", 1)
    add_paragraph(
        doc,
        "本手册把当前系统拆成可以独立恢复的五个层次：本地项目、固定工具链、Codex 能力栈、"
        "Headroom 代理路径和原生 Computer Use 验收。最终结果不是一堆“看起来已安装”的插件，"
        "而是一条能持续产生提交、真实 GUI 证据和可审计状态的工作流水线。",
    )
    add_bullets(
        doc,
        [
            "代码、测试、构建、发布资格与 GUI 验收彼此有明确边界。",
            "所有可下载依赖固定版本并校验；未知版本失败关闭。",
            "Agent 固定为 Developer 与 Tester 两个原生线程，模型固定为 Flash Max。",
            "GUI PASS 必须有真实截图、鼠标、键盘、AX 变化、console 未变和精确 PID 清理。",
            "没有 Apple Developer ID 与公证凭据时，只生成可信的本地 ad-hoc 候选，不声称可公开发布。",
        ],
    )
    add_figure(doc, architecture, "图 1  恢复后的系统边界。代码路由与 GUI 验收互不替代。")
    add_heading(doc, "1.1 不迁移的内容", 2)
    add_table(
        doc,
        ["旧对象", "迁移决定", "原因"],
        [
            ["CuaDriver", "删除，不恢复", "与 Codex 原生 Computer Use 重复，增加隔离墙和输入误差"],
            ["godot-test 账户", "删除，不恢复", "GUI 输入仍受 macOS 控制台与 HID 边界影响"],
            ["共享 GUI 队列", "删除，不恢复", "候选调度与真实 GUI 会话耦合，容错差"],
            ["console session broker", "删除，不恢复", "用系统级切会话掩盖本应重新设计的验收路径"],
            ["auth.json / Cookie / API Key", "永不打包", "凭证必须由用户在新机安全登录流程中生成"],
            ["旧聊天与运行状态", "不复制", "任务、租约和线程 ID 绑定账户与机器会话"],
        ],
        [1.65, 1.2, 3.95],
    )


def add_prereq_section(doc: Document) -> None:
    add_heading(doc, "2 新机前置条件与人工门", 1)
    add_paragraph(
        doc,
        "以下事项必须由机器所有者完成。脚本不会替你输入密码、读取密钥、授予隐私权限，"
        "也不会创建替代 Agent。",
    )
    add_table(
        doc,
        ["门", "操作", "通过标准"],
        [
            ["Xcode 工具", "运行 xcode-select --install", "xcode-select -p 返回有效路径"],
            ["ChatGPT Desktop", "从官方渠道安装并登录同一账户", "Codex 能正常打开并新建 turn"],
            ["DeepSeek 凭据", "在本机 Codex 配置中设置已有凭据", "deepseek provider 段存在且不向对话暴露密钥"],
            ["Computer Use", "在 Codex 插件中启用", "存在 ~/.codex/computer-use/Codex Computer Use.app"],
            ["隐私权限", "系统设置中允许辅助功能与屏幕录制", "原生 Computer Use 首次截图与输入成功"],
            ["线程", "复用原 Developer/Tester，或手工创建恰好两个原生线程", "线程设置显示 deepseek-flash / max"],
        ],
        [1.35, 2.75, 2.7],
    )
    add_heading(doc, "2.1 DeepSeek 配置的安全写法", 2)
    add_paragraph(
        doc,
        "如果新机配置中还没有 DeepSeek provider，请在本地 Codex 配置中加入下面的结构，"
        "但必须用你自己的密码管理器或现有配置填入凭据。不要把凭据发送给 Agent、写入本包或粘贴到聊天。",
    )
    add_code(
        doc,
        'model = "deepseek-flash"\n'
        'model_provider = "deepseek"\n'
        'model_reasoning_effort = "max"\n\n'
        '[model_providers.deepseek]\n'
        'name = "DeepSeek via Headroom"\n'
        'base_url = "http://127.0.0.1:8787/v1"\n'
        'wire_api = "responses"\n'
        "supports_websockets = false\n"
        'experimental_bearer_token = "<LOCAL_SECRET>"\n',
    )
    add_paragraph(
        doc,
        "保存后确认 ~/.codex/config.toml 权限为 600。30-configure-codex.command 只检查凭据是否存在，"
        "不会打印其值，也不会把凭据复制到交付包。",
    )


def add_flow_section(doc: Document, workflow: Path) -> None:
    add_heading(doc, "3 五阶段恢复流程", 1)
    add_figure(doc, workflow, "图 2  安装按依赖顺序推进。第 4 阶段不能被脚本静默越过。")
    add_table(
        doc,
        ["步骤", "命令", "成功输出", "失败时"],
        [
            ["只读体检", "./01-inspect.command", "PASS 只读体检", "先修硬失败；WARN 留给后续"],
            ["基础环境", "./10-bootstrap.command", "PASS bootstrap", "保留已下载缓存，修正后重跑"],
            ["项目工具链", "./20-install-project.command", "PASS project-toolchain", "校验失败时移走坏缓存后重跑"],
            ["路由授权", "./30-configure-codex.command", "PASS codex-routing", "停止，不重启 Desktop 掩盖问题"],
            ["线程绑定", "./35-bind-native-threads.command", "BOUND developer=… tester=…", "仅在新的线程 ID 确实不同时运行"],
            ["最终验收", "./40-verify.command", "PASS new-mac-verification", "按最先失败的域隔离，不跳门"],
        ],
        [1.15, 2.2, 1.75, 1.7],
    )


def add_installation_details(doc: Document) -> None:
    add_heading(doc, "4 各阶段执行细节", 1)
    add_heading(doc, "4.1 只读体检", 2)
    add_paragraph(
        doc,
        "体检不安装、不覆盖、不启动游戏。它检查命令、Xcode、ChatGPT、Computer Use、插件开关、"
        "项目提交、Godot、Node、开发工具、两个 Agent 克隆和废弃 GUI 组件。"
        "发现旧 CuaDriver、godot-test 共享队列或 console broker 时直接判硬失败。",
    )

    add_heading(doc, "4.2 基础环境", 2)
    add_paragraph(
        doc,
        "bootstrap 先验证项目 bundle 的 main 提交，再从 bundle 建立主克隆。"
        "随后安装固定 uv、Headroom 与离线技能源，并从主克隆创建 Developer/Tester 两个独立克隆。"
        "每个克隆通过被 Git 忽略的 .tools 链接获得同一套固定工具，不复制供应商缓存。",
    )
    add_bullets(
        doc,
        [
            "目标路径非空且不是 Git 克隆时立即失败，不删除用户目录。",
            "项目提交必须包含交付清单中的基线提交。",
            "已有同名 awesome-gamedev 技能时失败，避免覆盖用户技能。",
            "Superpowers 固定为 7.0.1，awesome-gamedev 固定为提交 19d93f97。",
        ],
    )

    add_heading(doc, "4.3 项目工具链", 2)
    add_paragraph(
        doc,
        "Node.js、Godot、Godot macOS 导出模板、uv、ast-grep 与 Aider 全部落在项目或项目依赖的固定路径。"
        "Godot 导出模板约 1.28 GB，下载和校验是耗时最长的步骤。",
    )
    add_table(
        doc,
        ["组件", "固定版本", "作用"],
        [
            ["Node.js", "24.22.0", "ast-grep 安装与本地开发运行时"],
            ["Godot", "4.7.2 stable", "Headless 测试、导出、本地候选构建"],
            ["导出模板", "4.7.2.stable", "macOS .app 与 packaged tests"],
            ["uv", "0.13.5", "隔离 Python 工具环境"],
            ["ast-grep", "0.51.0", "Shell/Python/JSON 结构审查，不覆盖 GDScript"],
            ["Aider", "0.86.2", "隔离 worktree 中的受限辅助编辑"],
        ],
        [1.5, 1.45, 3.85],
    )

    add_heading(doc, "4.4 Codex 路由与 Headroom", 2)
    add_paragraph(
        doc,
        "路由脚本先启用 Superpowers、Game Studio、Product Design 与原生 Computer Use，"
        "再把现有 DeepSeek provider 的 base_url 指向本机 Headroom。它不替换 provider ID，"
        "不改变凭据，不启用 WebSocket，并保留可回滚配置备份。",
    )
    add_code(
        doc,
        "# 安全部署，仅创建受管 profile，不修改 provider 目标\n"
        "headroom install apply --providers manual --profile codex-deepseek\n\n"
        "# 仓库控制的 gateway 会替换受管 runner\n"
        "automation/headroom/headroom-control.sh ensure\n"
        "automation/headroom/headroom-control.sh verify",
    )
    add_paragraph(
        doc,
        "禁止使用 headroom wrap codex、headroom init codex，或任何会替换 provider 的路径。"
        "Headroom 不可恢复时停止派发；Desktop 重启不是代理故障的默认修复方式。",
    )

    add_heading(doc, "4.5 Agent 线程绑定", 2)
    add_paragraph(
        doc,
        "固定路由只允许两个原生线程：Developer 与 Tester。若新机仍能看到原线程，继续使用原 UUID。"
        "若账户或线程环境产生新 UUID，先手工创建恰好两个线程，分别设置模型后再运行绑定脚本。"
        "绑定脚本检查主克隆和两个独立克隆是否干净，更新路由、AGENTS.md 与救援提示中的 UUID，"
        "在 .game-auto/native-thread-bind-backups 下保留时间戳备份，提交主克隆并快进同步两个克隆。",
    )
    add_code(
        doc,
        "./35-bind-native-threads.command \\\n"
        "  <DEVELOPER_THREAD_ID> <TESTER_THREAD_ID>\n\n"
        "automation/native-agents/preflight.sh",
    )
    add_paragraph(
        doc,
        "每个新线程必须至少产生一次 thread_settings_applied 事件，且为 deepseek / deepseek-flash / max；"
        "否则 preflight 按设计失败。禁止创建第三个、替换 Agent、并行 reviewer 或 fallback 线程。",
    )


def add_computer_use_section(doc: Document) -> None:
    add_heading(doc, "5 原生 Computer Use 验收契约", 1)
    add_paragraph(
        doc,
        "当前系统已彻底转向 Codex 原生 Computer Use。它像独立屏幕一样工作，不要求切换专用账户，"
        "也不依赖外部输入桥。验收仍然必须严格，因为“能截图”不等于“产品行为正确”。",
    )
    add_table(
        doc,
        ["证据", "最低要求"],
        [
            ["应用绑定", "只操作精确候选 LoopedVows.app，不读取无关前台内容"],
            ["真实输入", "至少包含真实鼠标与键盘动作，不接受只改状态或只读代码"],
            ["状态变化", "AX before/after 均非空、哈希不同，并对应产品状态变化"],
            ["截图", "至少一张真实截图；每回合最多查看一张，禁止批量展示或推断未观察行为"],
            ["控制台边界", "console_user_before = console_user_after，前台应用未被错误夺走"],
            ["进程清理", "记录精确 PID，结束后 remaining_pids 为空"],
            ["候选绑定", "candidate SHA、二进制 SHA、PCK SHA、干净 source 清单一致"],
        ],
        [1.6, 5.2],
    )
    add_paragraph(
        doc,
        "Tester 不修改源码。Developer 不等待 Tester。Supervisor 只在独立 GUI PASS 后记录验收、"
        "整合已提交 SHA 并释放槽位。任何缺失证据都按 FAIL 处理。",
    )
    add_heading(doc, "5.1 首次权限自检", 2)
    add_bullets(
        doc,
        [
            "打开 ChatGPT Desktop 并确认 Computer Use 插件已启用。",
            "首次调用时在系统设置中授权辅助功能与屏幕录制。",
            "让 Codex 对一个无害应用执行一次截图，确认原生 Computer Use 可用。",
            "关闭测试应用，确认没有遗留精确 PID。",
            "不要在设置恢复前生成或重试产品候选。",
        ],
    )


def add_verification_section(doc: Document) -> None:
    add_heading(doc, "6 端到端验收矩阵", 1)
    add_paragraph(
        doc,
        "40-verify.command 依次验证交付包、配置、工具链、代理、调度与构建。"
        "它的目的不是增加仪式，而是确保每一个后续任务都能依靠同一套契约。",
    )
    add_table(
        doc,
        ["域", "验收", "失败关闭条件"],
        [
            ["包完整性", "MANIFEST.sha256、脚本语法、JSON、bundle、77 技能", "任何哈希或结构不一致"],
            ["路由", "provider/model/effort/base_url/MCP/plugins", "凭据不存在或路由字段不匹配"],
            ["Headroom", "ready、privacy、gateway、layout、doctor", "遥测开启、外部 Origin 可写、socket 权限过宽"],
            ["项目", "devtools、长跑、宿主、资源车道、能力门测试", "任一自动测试失败"],
            ["GDScript", "godot-court/check.sh 全套 Headless 测试", "脚本 UID、存档、平衡或性能回归"],
            ["构建", "Godot export + ad-hoc codesign + manifest", "source dirty 或 SHA/PCK 不一致"],
            ["Agent 路由", "preflight 精确核验两个线程为 Flash Max", "线程缺失、克隆缺失或模型漂移"],
        ],
        [1.3, 2.75, 2.75],
    )
    add_heading(doc, "6.1 通过后的唯一结论", 2)
    add_paragraph(
        doc,
        "当且仅当 40-verify.command 输出 PASS new-mac-verification，"
        "新机才具备进入产品队列的条件。这个结论不等于公开发布资格，也不等于某个未来候选已经通过 GUI。",
    )


def add_security_section(doc: Document) -> None:
    add_heading(doc, "7 安全、隔离与故障顺序", 1)
    add_heading(doc, "7.1 凭证与隐私", 2)
    add_bullets(
        doc,
        [
            "交付包不包含 auth.json、API Key、Cookie、聊天记录、SQLite 会话库或浏览器数据。",
            "路由脚本只判断凭据字段是否存在，不输出字段值。",
            "Headroom 绑定回环地址，外部 Host、Origin、Referer、跨站 Fetch Metadata 与非 JSON 写请求被拒绝。",
            "所有 Headroom 文件保持用户独占权限；匿名上传与本地遥测关闭。",
        ],
    )
    add_heading(doc, "7.2 故障隔离顺序", 2)
    add_table(
        doc,
        ["现象", "先做什么", "禁止动作"],
        [
            ["Codex 连接失败", "status → ensure 一次 → verify", "循环重启 Desktop 或替换 provider"],
            ["同类基础设施失败两次", "隔离共同根因并修复", "换 Agent、写说明或重试候选冒充修复"],
            ["宿主非 AC/开盖/PID/assertion", "报告 UNSAFE 并失败关闭", "全局 pmset 修改、模糊杀进程"],
            ["GUI 输入失败", "保留截图、AX、PID 与控制台证据", "伪造 PASS、改用未授权 GUI 桥"],
            ["签名/公证失败", "保留本地 ad-hoc 候选并标为阻塞", "声称可公开发布"],
        ],
        [1.7, 2.7, 2.4],
    )
    add_heading(doc, "7.3 回滚", 2)
    add_paragraph(
        doc,
        "路由应用前会创建 config.toml.before-looped-vows-new-machine。回滚脚本先把当前配置另存，"
        "再恢复旧配置，避免再次覆盖时丢失证据。回滚 Headroom 路由后，应重新启动 Desktop 并验证新 turn。",
    )
    add_code(doc, "./99-rollback-codex-route.command")


def add_troubleshooting_section(doc: Document) -> None:
    add_heading(doc, "8 常见问题与恢复动作", 1)
    add_table(
        doc,
        ["问题", "诊断", "恢复"],
        [
            ["脚本提示非空目录", "项目路径已有文件但不是 Git", "备份并移走目标，禁止让脚本自动删除"],
            ["Godot 模板下载很慢", "1.28 GB 下载与 SHA-512 校验", "保持网络与磁盘，重跑从已校验缓存继续"],
            ["同名技能已存在", "用户已有 router 或同名目录", "人工比较后移走旧目录；不要盲目覆盖"],
            ["Codex 路由检查失败", "配置字段或插件段缺失", "查看具体 key 名，修正配置后重跑 30"],
            ["Headroom 为 UNHEALTHY", "launchd 未启动或端口占用", "ensure 一次；失败即停止，不重启 Desktop"],
            ["Agent preflight 失败", "线程 ID、会话设置或克隆不完整", "先修正对应一项，再重新运行 preflight"],
            ["Computer Use 无权限", "macOS 隐私授权未完成", "在系统设置授权并重启 Desktop，不恢复旧驱动"],
        ],
        [1.55, 2.35, 2.9],
    )


def add_appendices(doc: Document) -> None:
    add_heading(doc, "附录 A 固定版本", 1)
    add_table(
        doc,
        ["组件", "版本或提交"],
        [
            ["macOS 基线", VERSIONS["baseline"]["macos"]],
            ["ChatGPT Desktop 基线", VERSIONS["baseline"]["chatgpt_desktop"]],
            ["Codex Computer Use 基线", VERSIONS["baseline"]["codex_computer_use"]],
            ["Looped Vows", VERSIONS["repository"]["commit"]],
            ["Node.js", VERSIONS["node"]["version"]],
            ["uv", VERSIONS["uv"]["version"]],
            ["Godot", VERSIONS["godot"]["version_full"]],
            ["Headroom", VERSIONS["headroom"]["version"]],
            ["Superpowers", VERSIONS["skills"]["superpowers"]["version"]],
            ["awesome-gamedev", VERSIONS["skills"]["awesome_gamedev"]["commit"]],
            ["ast-grep", VERSIONS["devtools"]["ast_grep"]],
            ["Aider", VERSIONS["devtools"]["aider"]],
        ],
        [2.0, 4.8],
    )
    add_heading(doc, "附录 B 交付文件", 1)
    add_table(
        doc,
        ["路径", "用途"],
        [
            ["01-inspect.command", "只读体检，不写系统"],
            ["10-bootstrap.command", "项目、uv、Headroom、技能源、双克隆"],
            ["20-install-project.command", "Node、Godot、模板、本地开发工具"],
            ["30-configure-codex.command", "插件、DeepSeek 路由、Headroom gateway"],
            ["35-bind-native-threads.command", "新 UUID 时同步两个原生线程绑定"],
            ["40-verify.command", "完整自动验收"],
            ["99-rollback-codex-route.command", "恢复 Codex provider 配置备份"],
            ["payload/looped-vows-repository.bundle", "固定提交的离线 Git bundle"],
            ["payload/superpowers-7.0.1.tar.gz", "Superpowers 7.0.1 离线源"],
            ["payload/awesome-gamedev-…tar.gz", "77 个游戏技能离线源"],
            ["MANIFEST.sha256", "包内每个交付文件的 SHA-256"],
        ],
        [2.55, 4.25],
    )
    add_heading(doc, "附录 C 最终检查清单", 1)
    checklist = [
        "ChatGPT Desktop 已登录，DeepSeek 凭据只存在于本机安全配置。",
        "原生 Computer Use 已启用，辅助功能与屏幕录制已授权。",
        "Headroom 返回 HEALTHY 与 verify PASS，telemetry=OFF。",
        "Developer 与 Tester 均为独立克隆，且每个克隆可访问固定 .tools。",
        "两个原生线程均为 deepseek-flash / max，preflight 通过。",
        "77 个 awesome-gamedev 技能与 Superpowers 7.0.1 可被 skill-stack 找到。",
        "godot-court/check.sh 与本地 macOS 构建通过。",
        "没有 CuaDriver、godot-test 共享队列、console broker 或遗留候选进程。",
        "公开发布仍明确保留为签名/公证凭据门，不用本地 ad-hoc 代替。",
    ]
    for item in checklist:
        paragraph = doc.add_paragraph(style="List Bullet")
        paragraph.paragraph_format.space_after = Pt(4)
        paragraph.add_run(item)
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(18)
    set_paragraph_border(paragraph, "top")
    run = paragraph.add_run(
        "维护原则：任何新增自动化只有在产生真实决策、产物、测试或验证时才计为“已使用”；"
        "安装、列出名称和写说明都不等于能力落地。"
    )
    set_run_font(run, FONT_BODY, size=10, bold=True, color=INK)


def build_docx(architecture: Path, workflow: Path) -> Path:
    MANUAL_DIR.mkdir(parents=True, exist_ok=True)
    output = MANUAL_DIR / "Looped-Vows-新机配置与迁移手册.docx"
    doc = Document()
    configure_styles(doc)
    add_header_footer(doc)
    add_cover(doc)
    add_executive_section(doc, architecture)
    add_prereq_section(doc)
    add_flow_section(doc, workflow)
    add_installation_details(doc)
    add_computer_use_section(doc)
    add_verification_section(doc)
    add_security_section(doc)
    add_troubleshooting_section(doc)
    add_appendices(doc)
    props = doc.core_properties
    props.title = "Looped Vows 新 Mac 配置与迁移手册"
    props.subject = "从空白 macOS 恢复 Looped Vows 开发、代理与原生 Computer Use 环境"
    props.author = "Looped Vows"
    props.keywords = "macOS, Codex, Computer Use, Godot, Headroom"
    doc.save(output)
    return output


def main() -> None:
    ASSET_DIR.mkdir(parents=True, exist_ok=True)
    architecture = make_architecture()
    workflow = make_workflow()
    output = build_docx(architecture, workflow)
    print(output)


if __name__ == "__main__":
    main()
