#!/usr/bin/env bash
set -euo pipefail

package_root="$(cd "$(dirname "$0")/../.." && pwd)"
source "$package_root/scripts/common.sh"
python_bin="$(python_command)"

test_root="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-route-test.XXXXXX")"
trap 'rm -rf "$test_root"' EXIT HUP INT TERM

home="$test_root/home"
codex_home="$home/.codex"
fake_python="$home/.local/share/uv/tools/headroom-ai/bin/python"
mkdir -p "$codex_home" "$(dirname "$fake_python")"
printf '#!/bin/sh\nexit 0\n' > "$fake_python"
chmod 755 "$fake_python"
config="$codex_home/config.toml"

cat > "$config" <<'EOF'
model = "other"
model_provider = "other"

[model_providers.other]
base_url = "https://example.invalid/v1"

[model_providers.deepseek]
env_key = "DEEPSEEK_API_KEY"
EOF
chmod 600 "$config"

output="$(
  HOME="$home" CODEX_HOME="$codex_home" \
    "$python_bin" "$package_root/scripts/configure-codex-route.py" --apply
)"
printf '%s\n' "$output" | grep -q 'PASS codex-route'
! printf '%s\n' "$output" | grep -q 'DEEPSEEK_API_KEY'

HOME="$home" CODEX_HOME="$codex_home" \
  "$python_bin" "$package_root/scripts/configure-codex-route.py" --check

HOME="$home" CODEX_HOME="$codex_home" \
  "$python_bin" "$package_root/scripts/configure-codex-route.py" --rollback
cmp -s "$config" "$config.before-looped-vows-new-machine"

printf 'PASS route-config-test\n'
