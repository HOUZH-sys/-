#!/usr/bin/env bash
set -euo pipefail

package_root="$(cd "$(dirname "$0")/../.." && pwd)"
source "$package_root/scripts/common.sh"
python_bin="$(python_command)"

test_root="$(mktemp -d "${TMPDIR:-/private/tmp}/looped-vows-bind-test.XXXXXX")"
trap 'rm -rf "$test_root"' EXIT HUP INT TERM

old_developer="11111111-1111-1111-1111-111111111111"
old_tester="22222222-2222-2222-2222-222222222222"
new_developer="33333333-3333-3333-3333-333333333333"
new_tester="44444444-4444-4444-4444-444444444444"
project="$test_root/project"
mkdir -p \
  "$project/automation/native-agents" \
  "$project/automation/nightshift"

printf '%s\n%s\n' "$old_developer" "$old_tester" > "$project/AGENTS.md"
printf '%s\n%s\n' "$old_developer" "$old_tester" \
  > "$project/automation/nightshift/CONTINUOUS-OPERATIONS-PLAYBOOK.md"
printf '%s\n%s\n' "$old_developer" "$old_tester" \
  > "$project/automation/nightshift/chatgpt-rescue-heartbeat-prompt.md"
printf '.game-auto/\n.tools/\n' > "$project/.gitignore"
jq -n \
  --arg developer "$old_developer" \
  --arg tester "$old_tester" \
  '{
    agents: {
      developer: {thread_id: $developer},
      tester: {thread_id: $tester}
    }
  }' > "$project/automation/native-agents/routing.json"

git -C "$project" init -q -b main
git -C "$project" add .
git -C "$project" -c user.name=Test -c user.email=test@example.invalid \
  commit -qm "initial"
mkdir -p "$project/.game-auto/agent-round"
for role in developer tester; do
  git clone -q --no-hardlinks "$project" "$project/.game-auto/agent-round/$role"
done

output="$(
  "$python_bin" "$package_root/scripts/bind-native-threads.py" \
    --project "$project" \
    --developer "$new_developer" \
    --tester "$new_tester" \
    --apply
)"
printf '%s\n' "$output" | grep -q '^COMMITTED '
printf '%s\n' "$output" | grep -q '^SYNCED developer='
printf '%s\n' "$output" | grep -q '^SYNCED tester='

main_head="$(git -C "$project" rev-parse HEAD)"
[ "$(git -C "$project/.game-auto/agent-round/developer" rev-parse HEAD)" = "$main_head" ]
[ "$(git -C "$project/.game-auto/agent-round/tester" rev-parse HEAD)" = "$main_head" ]
[ -z "$(git -C "$project" status --porcelain)" ]
! rg -q "$old_developer|$old_tester" \
  "$project/AGENTS.md" \
  "$project/automation/native-agents/routing.json" \
  "$project/automation/nightshift/CONTINUOUS-OPERATIONS-PLAYBOOK.md" \
  "$project/automation/nightshift/chatgpt-rescue-heartbeat-prompt.md"
find "$project/.game-auto/native-thread-bind-backups" -type f | grep -q .

"$python_bin" "$package_root/scripts/bind-native-threads.py" \
  --project "$project" \
  --developer "$new_developer" \
  --tester "$new_tester" \
  --check | grep -q 'PASS native-thread-binding'

printf 'dirty\n' >> "$project/AGENTS.md"
if "$python_bin" "$package_root/scripts/bind-native-threads.py" \
  --project "$project" \
  --developer "$old_developer" \
  --tester "$old_tester" \
  --apply 2>/dev/null; then
  fail "脏主克隆没有被拒绝"
fi

printf 'PASS native-thread-binding-test\n'
