#!/bin/bash
set -euo pipefail

root="$(cd "$(dirname "$0")" && pwd)"
source "$root/scripts/common.sh"
run_launcher "$root/scripts/inspect.sh"
