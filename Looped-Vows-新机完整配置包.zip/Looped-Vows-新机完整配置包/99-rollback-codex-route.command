#!/bin/bash
set -euo pipefail

root="$(cd "$(dirname "$0")" && pwd)"
source "$root/scripts/common.sh"
printf '这会恢复最近一次由本包保存的 Codex 路由配置。\n'
printf '当前配置会另存为 before-rollback 备份。\n'
if [ -t 0 ]; then
  printf '输入 ROLLBACK 继续: '
  read -r confirmation
  [ "$confirmation" = "ROLLBACK" ] || fail "rollback cancelled"
fi
py="$(python_command)"
"$py" "$root/scripts/configure-codex-route.py" --rollback
pause_if_interactive
